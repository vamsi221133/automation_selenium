package classroomprctc;

public class Sub_SingletTonClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletTonClass.getInstance().method();
		SingletTonClass.getInstance().method1();
		SingletTonClass.getInstance().method2();
		SingletTonClass.getInstance().method3();
		
		

	}

}
