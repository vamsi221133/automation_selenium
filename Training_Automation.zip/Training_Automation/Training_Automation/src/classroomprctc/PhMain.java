package classroomprctc;

public class PhMain {

	public static void main(String[] args) {
		//PhDemo obj = new PhDemo();
		PhDemo obj1 = new PhDemo(20, 30);
				obj1.Phmodel();
				PhDemo.Phprice();
				obj1.Phram();
				obj1.Prom();
	}

}
