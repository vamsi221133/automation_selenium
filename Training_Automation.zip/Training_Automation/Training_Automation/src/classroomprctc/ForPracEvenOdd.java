package classroomprctc;

public class ForPracEvenOdd {

	public static void main(String[] args) {
		{
		System.out.println("even numbers are");
		for (int i =0;i<15;i++) {
			
			if(i%2==0) {
				System.out.println(i);
			}
		}}
		{System.out.println("odd numbers are");
			for (int j =0;j<15;j++) {
				if(j%2!=0)
			System.out.println(j);
			
		}
}}}


