package trails;

public class s123 {

	public static void main(int[] args) {
		System.out.println("main1");
	}

}
