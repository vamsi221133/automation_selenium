package classroomprctc;

public class Sample1 {

	public static void main(String[] args) {
		
		Demo1 obj = new Demo1();
		obj.add();
		//Demo1.add();
		//obj.mult(20, 30);
		obj.mult(Demo1.a, Demo1.b);
		
	}

}
