package classroomprctc;

public class Abstract3main extends Abstract2 {

	public static void main(String[] args) {
		
		Abstract2 obj = new Abstract3main();
	//	obj.id();
	//	obj.name();
		//obj.profision();
		obj.urname();
		Abstract123 ob = new Abstract2();
		ob.urname();
		//ob.sample();
		ob.urname();
		Abstract3main oo =new Abstract3main();
	}

}
