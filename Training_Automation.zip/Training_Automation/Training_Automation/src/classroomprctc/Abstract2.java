package classroomprctc;

public class Abstract2 extends Abstract123 {
	void id() {
		System.out.println("this id is from abstract1 in 2");
	}
	void name1() {
		System.out.println("this name is also form abstr 1 in 2");
	}
	@Override
	void profision() {
		System.out.println("this profision is from abstr1 in 2");
	}
	@Override
	void vamsi() {
		System.out.println("vamsi");// TODO Auto-generated method stub
		
	}
	@Override
	void name() {
		// TODO Auto-generated method stub
		
	}
	

}
