package classroomprctc;

public class IfPrac_main {

	public static void main(String[] args) {
		IfPrac obj = new IfPrac();
		obj.ifloop("vam");
		obj.nestedif(6);
		obj.switchcase("/");
		//System.out.println();
	}
}
