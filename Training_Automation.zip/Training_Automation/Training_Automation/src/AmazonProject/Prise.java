package AmazonProject;

public interface Prise {
	
	 void mobilep();
	

}
