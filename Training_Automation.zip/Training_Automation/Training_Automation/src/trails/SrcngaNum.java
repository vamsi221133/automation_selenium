package trails;

import java.util.Scanner;

public class SrcngaNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("enter number of elements");
		int n = sc.nextInt();
		System.out.println("enter \t"+n+" values");
		for(int i=0;i<n;i++) {
			//int[] eles[] = sc.nextInt();
			
		//}

	}

}}
