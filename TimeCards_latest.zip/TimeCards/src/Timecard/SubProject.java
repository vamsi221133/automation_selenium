package Timecard;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SubProject {
	public static WebDriver driver;
	public static void inti() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\training02\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://connect.maveric-systems.com/");
		driver.manage().window().maximize();
	}
	public static void Login(String username,String password) {
		WebElement ele = driver.findElement(By.xpath("//*[@id='LoginForm_username']"));
		ele.sendKeys(username);
		driver.findElement(By.xpath("//*[@id='LoginForm_password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	}
	public static void cards() throws InterruptedException {
	Actions act = new Actions(driver);
	Thread.sleep(1500);
	WebElement ele =   driver.findElement(By.xpath("(//a[@style='padding-right: 23px;'])[6]"));
	act.moveToElement(ele);

	Thread.sleep(1500);
	WebElement mytimecard  =   driver.findElement(By.xpath("//*[text()='Add Timecard']"));
	act.moveToElement(mytimecard);
	Thread.sleep(1500);
	act.click().build().perform();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.findElement(By.xpath("//select[@onchange='textchange()']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@onchange='textchange()']//option[2]")).click();
	Thread.sleep(1500);
	
	driver.findElement(By.xpath("//select[@name='TimesheetItems[client_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[client_id]']//option[2]")).click();
	Thread.sleep(1500);
	
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_id]']//option[2]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[sub_project_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[activity_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[activity_id]']//option[19]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_location]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_location]']//option[3]")).click();
	Thread.sleep(1500);
	
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration2']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration3']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration4']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration5']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration6']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration7']")).sendKeys("0");
	Thread.sleep(1500);
	
	driver.findElement(By.xpath("//input[@value='Save']")).click();
	Thread.sleep(1500);
	
	
	////for leave
	driver.findElement(By.xpath("//select[@onchange='textchange()']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@onchange='textchange()']//option[2]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[client_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[client_id]']//option[2]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_id]']//option[2]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[sub_project_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[activity_id]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[activity_id]']//option[14]")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_location]']")).click();
	Thread.sleep(1500);
	driver.findElement(By.xpath("//select[@name='TimesheetItems[project_location]']//option[3]")).click();
	Thread.sleep(1500);
	
	
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration2']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration3']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration4']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration5']")).sendKeys("0");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration6']")).sendKeys("8");
	Thread.sleep(1200);
	driver.findElement(By.xpath("//input[@id='TimesheetItems_duration7']")).sendKeys("8");
	Thread.sleep(1200);
}
	public static void submit() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element	= driver.findElement(By.xpath("//input[@value='Save']"));
		Thread.sleep(1000);
		js.executeScript("arguments[0].scrollIntoView();",element);
		element.click();
		Thread.sleep(1500);
		
		WebElement element1	= driver.findElement(By.xpath("//input[@id='submitweekly']"));
		Thread.sleep(1000);
		js.executeScript("arguments[0].scrollIntoView();",element1);
		element1.click();
		Thread.sleep(1500);
		System.out.println("time cards submited successfully");
	}
}