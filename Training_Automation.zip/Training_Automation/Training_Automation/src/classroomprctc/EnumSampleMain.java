package classroomprctc;

public class EnumSampleMain {

	public static void main(String[] args) {
		EnumSample var = EnumSample.vamsi;
		EnumSample var1 = EnumSample.control;
		System.out.println(EnumSample.capture);
		System.out.println(var);
	}
}
