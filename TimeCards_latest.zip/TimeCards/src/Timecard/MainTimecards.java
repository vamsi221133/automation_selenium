package Timecard;

public class MainTimecards extends SubProject{
	public static void main(String[] args) throws InterruptedException {
		SubProject obb = new SubProject();
		obb.inti();
		obb.Login("vamsikrishnaa", "Maveric@3");
		for(int i=0;i<6;i++) {
			obb.cards();
			obb.submit();
		}
		}

}
