package trails;

public class InterfaceEx {
	

}
