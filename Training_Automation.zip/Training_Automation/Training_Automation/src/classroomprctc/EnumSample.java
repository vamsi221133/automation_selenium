package classroomprctc;

public enum EnumSample {
	control,
	click,
	capture,
	space,
	vamsi,
	mourya,
	manju
	
}
