package classroomprctc;

public abstract class Abstract1 {
	abstract void id();
	abstract void name();
	abstract void urname();
	abstract void profision();
	void sample() {
		System.out.println("non abstraciton method");
	}

}
