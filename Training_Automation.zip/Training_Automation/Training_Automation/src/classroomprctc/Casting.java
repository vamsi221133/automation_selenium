package classroomprctc;

public class Casting {

	public static void main(String[] args) {
		
		double x ='a';
		float fl = (float) x;
		
		 int i = (int) x;
		 System.out.println(x);
		System.out.println(fl);//narro casting
		
		char y = 'v';
		double j = y ;//widing casting
		System.out.println(j);
		System.out.println(y);
	}

}
       