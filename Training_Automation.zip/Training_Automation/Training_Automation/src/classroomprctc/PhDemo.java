package classroomprctc;

public class PhDemo {
	int ab;
	int bc;
	PhDemo(){
		System.out.println("haii this is construcor for demo class");
	}
	PhDemo(int ab , int bc){
		this.ab=ab;
		this.bc = bc;
		System.out.println("a value"+ab);
		System.out.println("a value"+bc);
	}

	public void Phmodel() {
		System.out.println("realme 5 pro");
	}
	public static void Phprice() {
		System.out.println("Rs.15000");
	}
	public void Phram() {
		System.out.println("6gb");
	}
	public void Prom() {
		System.out.println(ab+","+bc);
	}
	
	
}
