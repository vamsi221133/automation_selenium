package classroomprctc;

public interface Intrfac1 extends Intrfac{
	
	public default void name() {
		System.out.println("murya");
	}
	/*public default void myname() {
		System.out.println("muryakandan");
	}*/
	public void inf1();

}
