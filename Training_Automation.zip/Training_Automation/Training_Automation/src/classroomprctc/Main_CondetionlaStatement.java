package classroomprctc;

public class Main_CondetionlaStatement {
	
	public static void main(String args[]) {
		CondetionlaStatement.getInsta().mymethod(16);
		CondetionlaStatement.getInsta().mymethod1("java", "selenium");
		CondetionlaStatement.getInsta().swithEx("41154242");
	}

}
