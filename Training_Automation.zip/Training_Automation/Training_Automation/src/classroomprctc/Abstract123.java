package classroomprctc;

public abstract class Abstract123 extends Abstract1{
	
	void urname() {
		System.out.println("asdfasdf");
	}
	abstract void vamsi();
}
