package classroomprctc;

public class MathEx {

	public static void main(String[] args) {
		int x=5;
		int y =8;
		System.out.println(Math.max(x, y)); 

	}

}
